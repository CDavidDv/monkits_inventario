<?php echo "PHP OK - version: " . phpversion(); ?>
